package com.example.dailyexpensemanager;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;
import java.util.Date;

public class AddBill extends AppCompatActivity {
    private static final String TAG = "AddBill";
    DatePickerDialog.OnDateSetListener onDateSetListener;
    EditText e1, e2, e3;
    Button bbil;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bill);
        e1 = (EditText) findViewById(R.id.amt2);
        e2 = (EditText) findViewById(R.id.des2);
        e3 = (EditText) findViewById(R.id.dat2);
        bbil = (Button) findViewById(R.id.adbil);

        e3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(
                        AddBill.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

            }
        });
        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                Log.d(TAG, "onDataSet: date:" + year + "/" + month + "/" + dayOfMonth);
                String date = month + "/" + dayOfMonth + "/" + year;
                e3.setText(date);
            }
        };
        db = openOrCreateDatabase("DailyexpenseDB", Context.MODE_PRIVATE, null);
        if (db != null) {

        }
        db.execSQL("CREATE TABLE IF NOT EXISTS bill(amount INTEGER,type VARCHAR,deadline DATE)");
        bbil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (e1.getText().toString().trim().length() == 0 || e2.getText().toString().trim().length() == 0 || e3.getText().toString().trim().length() == 0) {
                    showmessage("Error", "Please enter all the values");
                    return;
                } else {
                    db.execSQL("INSERT INTO bill VALUES('" + e1.getText() + "','" + e2.getText() + "','" + e3.getText() + "')");
                    showmessage("Success", "Bill added successfully");
                    cleartext();
                    Intent in = new Intent(AddBill.this, MainActivity.class);
                    startActivity(in);
                }
            }
        });
    }
    public void showmessage(String title,String msg)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(msg);
        builder.show();
    }
    public void cleartext()
    {
        e1.setText("");
        e2.setText("");
        e3.setText("");
        e1.requestFocus();
    }
}
