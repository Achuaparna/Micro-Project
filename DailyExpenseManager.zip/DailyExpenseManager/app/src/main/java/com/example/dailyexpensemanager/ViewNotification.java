package com.example.dailyexpensemanager;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewNotification extends AppCompatActivity {
    SQLiteDatabase db;
    ArrayList<String> name=new ArrayList<String>();
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_notification);
        listView=(ListView)findViewById(R.id.lv1);

        db = openOrCreateDatabase("DailyexpenseDB", Context.MODE_PRIVATE, null);
        if (db != null) {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }

        db.execSQL("CREATE TABLE IF NOT EXISTS bill(amount INTEGER,type VARCHAR,deadline DATE)");
        Cursor c = db.rawQuery("SELECT * FROM bill", null);
        if (c.getCount() == 0) {
            showMessage("Error", "No records found");
            return;
        }
        while (c.moveToNext()) {
            int nm=c.getInt(0);
            String des=c.getString(1);
            String da=c.getString(2);
            name.add(""+nm);
            name.add(des);
            name.add(da);
        }
        ArrayAdapter<String> ad = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,name);
        listView.setAdapter(ad);

    }


    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
