package com.example.dailyexpensemanager;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class AddIncome extends AppCompatActivity {
    private static final String TAG="AddIncome";
    DatePickerDialog.OnDateSetListener onDateSetListener;

    EditText amt,des,dat;
    Button add;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_income);
        amt = (EditText) findViewById(R.id.amt);
        des = (EditText) findViewById(R.id.des);
        dat = (EditText) findViewById(R.id.dat);
        add = (Button) findViewById(R.id.add);
        dat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dialog = new DatePickerDialog(
                        AddIncome.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        onDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

            }
        });
        onDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month=month+1;
                Log.d(TAG, "onDataSet: date:" + year + "/" + month + "/" + dayOfMonth);
                String date=month+"/"+dayOfMonth+"/"+year;
                dat.setText(date);
            }
        };

        db=openOrCreateDatabase("DailyexpenseDB", Context.MODE_PRIVATE,null);
        if(db!=null)
        {

        }
        db.execSQL("CREATE TABLE IF NOT EXISTS expensedetai(amount INTEGER,decsrip VARCHAR,dat DATE,type VARCHAR)");
        db.execSQL("CREATE TABLE IF NOT EXISTS income(id INTEGER,amount INTEGER)");
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(amt.getText().toString().trim().length()==0||des.getText().toString().trim().length()==0||dat.getText().toString().trim().length()==0)
                {
                    showmessage("Error","Please enter all the values");
                    return;
                }
                else {
                    db.execSQL("INSERT INTO expensedetai VALUES('" + amt.getText() + "','" + des.getText() + "','" + dat.getText() + "','income')");
                    db.execSQL("INSERT INTO income VALUES('1','"+amt.getText()+"')");
                    db.execSQL("UPDATE income SET amount=amount+'"+amt.getText()+"'WHERE id='1'");
                    showmessage("Success", "Income added successfully");
                    cleartext();
                    Intent in = new Intent(AddIncome.this, MainActivity.class);
                    startActivity(in);
                }
            }
        });
    }
    public void showmessage(String title,String msg)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(msg);
        builder.show();
    }
    public void cleartext()
    {
        amt.setText("");
        des.setText("");
        dat.setText("");
        amt.requestFocus();
    }
}
